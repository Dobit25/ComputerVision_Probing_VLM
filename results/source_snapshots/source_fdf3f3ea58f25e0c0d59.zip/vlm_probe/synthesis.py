"""Unified synthesis runner for P1.2, P2, P3, and P4 diagnostics (`reports/synthesis_v1/`).

Executes all deterministic offline diagnostics on the frozen repository artifacts
without modifying any historical run directory under `results/`.
"""

from pathlib import Path

from .depth.blinded_review import export_blinded_sheets
from .depth.common import ROOT
from .io_utils import write_json
from .prompt_study.offline_analysis import analyze_saved_probing_ensembles
from .spatial_diagnostics.mechanism import analyze_frozen_spatial_runs
from .spatial_diagnostics.quadrant_mitigation import evaluate_geometric_upper_bound
from .vietnamese_study.bpe_diagnostics import analyze_bpe_tokenization

SYNTHESIS_DIR = ROOT / "reports/synthesis_v1"


def build_synthesis_markdown(blinded, spatial_psr, spatial_geom, prompt_ens, bpe_diag):
    """Render a comprehensive Vietnamese Markdown summary of P1.2, P2, P3, and P4 diagnostics."""
    syn_t0 = spatial_psr["synthetic_depth"]["conditions"]["t0_o0_horizontal"]
    nat_exp_t2 = spatial_psr["natural_exploratory"]["conditions"]["t2_o0_horizontal"]
    nat_conf_t2 = spatial_psr["natural_confirmation"]["conditions"]["t2_o0_horizontal"]

    neg = prompt_ens["negation_probing_v1"]
    neg_mech = neg["mechanistic_breakdown"]

    sp_syn_ens = prompt_ens["synthetic_spatial_depth_v1"]["four_way_forward_templates"]
    sp_conf_ens = prompt_ens["natural_spatial_confirmation_v1"]["horizontal_2x2_assignment"]
    cat_ens = prompt_ens["cifar100_category_depth_v1"]["semantic_valid_3_templates"]

    bpe_p = bpe_diag["cifar100_prompts_summary"]
    bpe_l = bpe_diag["cifar100_labels_summary"]

    geom_syn = spatial_geom["synthetic_depth_1440"]
    geom_exp = spatial_geom["natural_exploratory_200"]
    geom_conf = spatial_geom["natural_confirmation_100"]

    lines = [
        "# Báo Cáo Tổng Hợp Chẩn Đoán Cơ Chế, Độ Nhạy Prompt & Phân Mảnh BPE Tiếng Việt (`synthesis_v1`)",
        "",
        "Tài liệu này được sinh tự động và tất định bởi `python -m vlm_probe.synthesis` từ các artifact đã đóng băng trong `results/`.",
        "",
        "---",
        "",
        "## 1. P1.2 — Trạng Thái Xuất Bảng Chấm Mù Độc Lập (Blinded Review Sheets)",
        "",
        "| Bộ dữ liệu | Số nguồn ảnh | File bảng chấm mù (CSV) | SHA-256 bảng chấm mù |",
        "| --- | ---: | --- | --- |",
        f"| **Confirmation (`100` nguồn ngang)** | `{blinded['confirmation_100']['num_items']}` | `{blinded['confirmation_100']['sheet_csv']}` | `{blinded['confirmation_100']['sheet_sha256'][:16]}...` |",
        f"| **Exploratory (`200` nguồn 4 hướng)** | `{blinded['exploratory_200']['num_items']}` | `{blinded['exploratory_200']['sheet_csv']}` | `{blinded['exploratory_200']['sheet_sha256'][:16]}...` |",
        "",
        "---",
        "",
        "## 2. P2.1–P2.3 — Phân Rã Prior-to-Signal Ratio (`PSR`) & Giới Hạn Hình Học Cắt Vùng Không Gian",
        "",
        "### 2.1. Phân rã Prior Bias $\\lvert B \\rvert$ so với Spatial Signal $\\lvert \\Delta_{\\text{spatial}} \\rvert$ trên các cặp đối xứng ngang",
        "",
        "| Benchmark & Điều kiện | Số cặp | $\\mathbb{E}[\\lvert B \\rvert]$ (Prior Bias) | $\\mathbb{E}[\\lvert \\Delta_{\\text{spatial}} \\rvert]$ (Spatial Signal) | Tỷ số $\\text{PSR} = \\frac{\\mathbb{E}[\\lvert B \\rvert]}{\\mathbb{E}[\\lvert \\Delta \\rvert]}$ | Tỷ lệ $\\lvert B \\rvert > \\lvert \\Delta \\rvert$ (Collapse 1 nhãn) | 2×2 Assignment Acc | Both Images Correct |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
        f"| **Synthetic Depth (`T0` thuận, ngang)** | `{syn_t0['n_pairs']}` | `{syn_t0['mean_abs_prior_bias_B']:.5f}` | `{syn_t0['mean_abs_spatial_signal_delta']:.5f}` | **`{syn_t0['aggregate_prior_to_signal_ratio']:.2f}x`** | `{syn_t0['same_prediction_collapse_percent']:.2f}%` | `{syn_t0['assignment_accuracy_percent']:.2f}%` | **`{syn_t0['both_images_correct_percent']:.2f}%`** |",
        f"| **COCO Exploratory (`T2` thuận, ngang)** | `{nat_exp_t2['n_pairs']}` | `{nat_exp_t2['mean_abs_prior_bias_B']:.5f}` | `{nat_exp_t2['mean_abs_spatial_signal_delta']:.5f}` | **`{nat_exp_t2['aggregate_prior_to_signal_ratio']:.2f}x`** | `{nat_exp_t2['same_prediction_collapse_percent']:.2f}%` | `{nat_exp_t2['assignment_accuracy_percent']:.2f}%` | **`{nat_exp_t2['both_images_correct_percent']:.2f}%`** |",
        f"| **COCO Confirmation (`T2` thuận, ngang)** | `{nat_conf_t2['n_pairs']}` | `{nat_conf_t2['mean_abs_prior_bias_B']:.5f}` | `{nat_conf_t2['mean_abs_spatial_signal_delta']:.5f}` | **`{nat_conf_t2['aggregate_prior_to_signal_ratio']:.2f}x`** | `{nat_conf_t2['same_prediction_collapse_percent']:.2f}%` | `{nat_conf_t2['assignment_accuracy_percent']:.2f}%` | **`{nat_conf_t2['both_images_correct_percent']:.2f}%`** |",
        "",
        "> **Kết luận cơ chế (`RQ2`):** Trên cả ảnh hình học tổng hợp lẫn ảnh tự nhiên COCO, độ lớn tuyệt đối của thiên kiến bất biến vị trí $\\mathbb{E}[\\lvert B \\rvert]$ lớn gấp **`"
        f"{nat_conf_t2['aggregate_prior_to_signal_ratio']:.1f}`–`{syn_t0['aggregate_prior_to_signal_ratio']:.1f}` lần** tín hiệu đổi chỗ không gian $\\mathbb{{E}}[\\lvert \\Delta_{{\\text{{spatial}}}} \\rvert]$. "
        "Do $\\lvert B \\rvert > \\lvert \\Delta_{\\text{spatial}} \\rvert$ trên hơn `93%–98,6%` số cặp, hai ảnh đối xứng bị đẩy về cùng một nhãn dự đoán, giải thích chính xác tại sao `both_images_correct` chỉ đạt `1,11%–4,00%` dù 2×2 assignment đạt `45%–54%`.",
        "",
        "### 2.2. Giới hạn hình học của phương pháp chia nửa khung hình (Half-Canvas Zero-Shot Mitigation — P2.2/P2.3)",
        "",
        "| Tập dữ liệu | Số nguồn ảnh | Tỷ lệ 2 vật thể nằm khác phía đường chia tâm | Độ chính xác 4-way lý tưởng khi chia nửa ảnh | Tỷ lệ 2 vật thể cùng nằm về 1 nửa ảnh |",
        "| --- | ---: | ---: | ---: | ---: |",
        f"| **Synthetic Depth (`1.440` ảnh)** | `{geom_syn['n_images']}` | **`{geom_syn['straddles_midline_rate_percent']:.2f}%`** | **`{geom_syn['four_way_accuracy_percent']:.2f}%`** | `0.00%` |",
        f"| **COCO Exploratory (`200` nguồn)** | `{geom_exp['n_sources']}` | `{geom_exp['objects_straddle_image_midline_percent']:.2f}%` | `{geom_exp['ideal_half_canvas_four_way_accuracy_percent']:.2f}%` | `{geom_exp['both_objects_in_same_half_percent']:.2f}%` (`{geom_exp['both_objects_in_same_half_count']}` ảnh) |",
        f"| **COCO Confirmation (`100` nguồn ngang)** | `{geom_conf['n_sources']}` | `{geom_conf['objects_straddle_image_midline_percent']:.2f}%` | `{geom_conf['ideal_half_canvas_horizontal_two_way_accuracy_percent']:.2f}%` (2-way) | `{geom_conf['both_objects_in_same_half_percent']:.2f}%` (`{geom_conf['both_objects_in_same_half_count']}` ảnh) |",
        "",
        "---",
        "",
        "## 3. P3.1–P3.4 — Độ Nhạy Prompt & Hiệu Quả Ensembling Trên Các Run Đã Đóng Băng",
        "",
        "### 3.1. Tác vụ Phủ định (Negation — `720` cảnh hình học độc lập)",
        "",
        "| Điều kiện / Ensemble | Accuracy tổng (`720` cảnh) | Present (`360` cảnh) | Absent (`360` cảnh) | Chênh lệch `Present - Absent` | Group Consistency (`180` nhóm) |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
        f"| **`with_without` (Single tốt nhất)** | `{neg_mech['with_without']['overall_accuracy_percent']:.2f}%` | `{neg_mech['with_without']['present_accuracy_percent']:.2f}%` | `{neg_mech['with_without']['absent_accuracy_percent']:.2f}%` | `{neg_mech['with_without']['present_minus_absent_gap_pp']:+.2f}` pp | `{neg_mech['with_without']['scene_pair_group_consistency_percent']:.2f}%` |",
        f"| **`contains_does_not` (Single kém nhất)** | `{neg_mech['contains_does_not']['overall_accuracy_percent']:.2f}%` | `{neg_mech['contains_does_not']['present_accuracy_percent']:.2f}%` | `{neg_mech['contains_does_not']['absent_accuracy_percent']:.2f}%` | `{neg_mech['contains_does_not']['present_minus_absent_gap_pp']:+.2f}` pp | `{neg_mech['contains_does_not']['scene_pair_group_consistency_percent']:.2f}%` |",
        f"| **Logit Average Ensemble** | **`{neg_mech['logit_average_ensemble']['overall_accuracy_percent']:.2f}%`** | `{neg_mech['logit_average_ensemble']['present_accuracy_percent']:.2f}%` | `{neg_mech['logit_average_ensemble']['absent_accuracy_percent']:.2f}%` | `{neg_mech['logit_average_ensemble']['present_minus_absent_gap_pp']:+.2f}` pp | **`{neg_mech['logit_average_ensemble']['scene_pair_group_consistency_percent']:.2f}%`** |",
        f"| **Probability Average Ensemble** | **`{neg_mech['probability_average_ensemble']['overall_accuracy_percent']:.2f}%`** | `{neg_mech['probability_average_ensemble']['present_accuracy_percent']:.2f}%` | `{neg_mech['probability_average_ensemble']['absent_accuracy_percent']:.2f}%` | `{neg_mech['probability_average_ensemble']['present_minus_absent_gap_pp']:+.2f}` pp | **`{neg_mech['probability_average_ensemble']['scene_pair_group_consistency_percent']:.2f}%`** |",
        "",
        "### 3.2. Tóm tắt biên độ nhạy (Spread) & Ensemble qua các bài toán",
        "",
        "| Bài toán | Số templates | Best Single | Worst Single | Mean ± SD | Spread (Max − Min) | Logit Ensemble | $\\Delta(\\text{Ens} - \\text{Baseline})$ [95% CI] |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |",
        f"| **Negation (`720` cảnh)** | `2` | `{neg['best_single_accuracy_percent']:.2f}%` | `{neg['worst_single_accuracy_percent']:.2f}%` | `{neg['mean_single_accuracy_percent']:.2f}% ± {neg['sd_single_accuracy_percent']:.2f}%` | **`{neg['spread_max_minus_min_pp']:.2f}` pp** | `{neg['ensembles']['logit_average_ensemble']['accuracy_percent']:.2f}%` | `{neg['ensembles']['logit_average_ensemble']['delta_vs_baseline_pp']:+.2f}` pp `[`{neg['ensembles']['logit_average_ensemble']['delta_vs_baseline_ci95_pp'][0]:+.2f}`, `{neg['ensembles']['logit_average_ensemble']['delta_vs_baseline_ci95_pp'][1]:+.2f}`]` |",
        f"| **Synthetic Spatial (`T0..T2` thuận, 4-way)** | `3` | `{sp_syn_ens['best_single_accuracy_percent']:.2f}%` | `{sp_syn_ens['worst_single_accuracy_percent']:.2f}%` | `{sp_syn_ens['mean_single_accuracy_percent']:.2f}% ± {sp_syn_ens['sd_single_accuracy_percent']:.2f}%` | **`{sp_syn_ens['spread_max_minus_min_pp']:.2f}` pp** | `{sp_syn_ens['ensembles']['logit_average_ensemble']['accuracy_percent']:.2f}%` | `{sp_syn_ens['ensembles']['logit_average_ensemble']['delta_vs_baseline_pp']:+.2f}` pp `[`{sp_syn_ens['ensembles']['logit_average_ensemble']['delta_vs_baseline_ci95_pp'][0]:+.2f}`, `{sp_syn_ens['ensembles']['logit_average_ensemble']['delta_vs_baseline_ci95_pp'][1]:+.2f}`]` |",
        f"| **CIFAR-100 Semantic Valid (`baseline/cat/neutral`)** | `3` | `{cat_ens['best_single_accuracy_percent']:.2f}%` | `{cat_ens['worst_single_accuracy_percent']:.2f}%` | `{cat_ens['mean_single_accuracy_percent']:.2f}% ± {cat_ens['sd_single_accuracy_percent']:.2f}%` | **`{cat_ens['spread_max_minus_min_pp']:.2f}` pp** | `{cat_ens['ensembles']['logit_average_ensemble']['accuracy_percent']:.2f}%` | `{cat_ens['ensembles']['logit_average_ensemble']['delta_vs_baseline_pp']:+.2f}` pp `[`{cat_ens['ensembles']['logit_average_ensemble']['delta_vs_baseline_ci95_pp'][0]:+.2f}`, `{cat_ens['ensembles']['logit_average_ensemble']['delta_vs_baseline_ci95_pp'][1]:+.2f}`]` |",
        "",
        f"- **Kiểm định Ensemble trên COCO Confirmation 2×2 Assignment (`100` cặp):** `T0` đạt `{sp_conf_ens['T0_forward']['assignment_accuracy_percent']:.2f}%`, `T1` đạt `{sp_conf_ens['T1_forward']['assignment_accuracy_percent']:.2f}%`, `T2` đạt `{sp_conf_ens['T2_forward']['assignment_accuracy_percent']:.2f}%`; khi gộp **Logit Ensemble (`T0+T1+T2`)** đạt `{sp_conf_ens['T0_T1_T2_forward_logit_ensemble']['assignment_accuracy_percent']:.2f}%` (CI 95% `[{sp_conf_ens['T0_T1_T2_forward_logit_ensemble']['assignment_ci95_percent'][0]:.2f}%, {sp_conf_ens['T0_T1_T2_forward_logit_ensemble']['assignment_ci95_percent'][1]:.2f}%]`) và `both_images_correct` vẫn chỉ đạt **`{sp_conf_ens['T0_T1_T2_forward_logit_ensemble']['both_images_correct_percent']:.2f}%`**. Điều này chứng minh **ensembling nhiều mẫu câu không thể giải cứu được hạn chế kiến trúc bag-of-words trên quan hệ không gian (`RQ3`)**.",
        "",
        "---",
        "",
        "## 4. P4.1 — Chẩn Đoán Phân Mảnh BPE Tokenization Trên Tiếng Việt (`100` Lớp CIFAR-100)",
        "",
        "| Điều kiện ngôn ngữ | Số BPE tokens / tên lớp (Mean ± SD) | Số BPE tokens / cả câu prompt (Mean ± SD) | Token Fertility (Tokens / từ đơn) | Tỷ số phân mảnh tên lớp so với Tiếng Anh | Số câu vượt ngưỡng `77` tokens |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
        f"| **`en_baseline` (Tiếng Anh)** | `{bpe_l['en_baseline']['mean_subword_tokens']:.2f} ± {bpe_l['en_baseline']['sd_subword_tokens']:.2f}` | `{bpe_p['en_baseline']['mean_subword_tokens']:.2f} ± {bpe_p['en_baseline']['sd_subword_tokens']:.2f}` | **`{bpe_l['en_baseline']['mean_token_fertility_per_word']:.2f}`** | `1.00x` | `{bpe_p['en_baseline']['exceeds_77_context_window_count']}` |",
        f"| **`vi_diacritics` (Tiếng Việt có dấu)** | **`{bpe_l['vi_diacritics']['mean_subword_tokens']:.2f} ± {bpe_l['vi_diacritics']['sd_subword_tokens']:.2f}`** | **`{bpe_p['vi_diacritics']['mean_subword_tokens']:.2f} ± {bpe_p['vi_diacritics']['sd_subword_tokens']:.2f}`** | **`{bpe_l['vi_diacritics']['mean_token_fertility_per_word']:.2f}`** | **`{bpe_l['vi_diacritics']['mean_ratio_vs_en_baseline']:.2f}x`** | `{bpe_p['vi_diacritics']['exceeds_77_context_window_count']}` |",
        f"| **`vi_no_diacritics` (Tiếng Việt không dấu)** | `{bpe_l['vi_no_diacritics']['mean_subword_tokens']:.2f} ± {bpe_l['vi_no_diacritics']['sd_subword_tokens']:.2f}` | `{bpe_p['vi_no_diacritics']['mean_subword_tokens']:.2f} ± {bpe_p['vi_no_diacritics']['sd_subword_tokens']:.2f}` | `{bpe_l['vi_no_diacritics']['mean_token_fertility_per_word']:.2f}` | `{bpe_l['vi_no_diacritics']['mean_ratio_vs_en_baseline']:.2f}x` | `{bpe_p['vi_no_diacritics']['exceeds_77_context_window_count']}` |",
        f"| **`vi_en_bilingual` (Song ngữ Việt–Anh)** | `{bpe_l['vi_en_bilingual']['mean_subword_tokens']:.2f} ± {bpe_l['vi_en_bilingual']['sd_subword_tokens']:.2f}` | `{bpe_p['vi_en_bilingual']['mean_subword_tokens']:.2f} ± {bpe_p['vi_en_bilingual']['sd_subword_tokens']:.2f}` | `{bpe_l['vi_en_bilingual']['mean_token_fertility_per_word']:.2f}` | `{bpe_l['vi_en_bilingual']['mean_ratio_vs_en_baseline']:.2f}x` | `{bpe_p['vi_en_bilingual']['exceeds_77_context_window_count']}` |",
        "",
        "> **Phát hiện định lượng (`RQ4`):** Bộ tách từ byte-level BPE của OpenAI CLIP bẻ một tên lớp tiếng Việt có dấu thành trung bình **`"
        f"{bpe_l['vi_diacritics']['mean_subword_tokens']:.2f}` subword tokens** (Fertility = **`{bpe_l['vi_diacritics']['mean_token_fertility_per_word']:.2f}` tokens/từ**), gấp **`{bpe_l['vi_diacritics']['mean_ratio_vs_en_baseline']:.2f}` lần** so với tên lớp tiếng Anh (`{bpe_l['en_baseline']['mean_subword_tokens']:.2f}` tokens). Khi lược bỏ dấu tiếng Việt (`vi_no_diacritics`), độ phân mảnh giảm mạnh xuống còn `{bpe_l['vi_no_diacritics']['mean_subword_tokens']:.2f}` tokens (`Fertility = {bpe_l['vi_no_diacritics']['mean_token_fertility_per_word']:.2f}`), chứng minh các ký tự nguyên âm mang dấu UTF-8 chính là nguyên nhân trực tiếp gây phân mảnh chuỗi subword trong BPE.",
        "",
    ]
    return "\n".join(lines)


def run_all_synthesis():
    """Execute all offline synthesis steps and write artifacts to `reports/synthesis_v1/`."""
    SYNTHESIS_DIR.mkdir(parents=True, exist_ok=True)
    blinded = export_blinded_sheets()
    write_json(SYNTHESIS_DIR / "blinded_review_manifest.json", blinded)

    spatial_psr = analyze_frozen_spatial_runs(output_path=SYNTHESIS_DIR / "spatial_mechanism_psr.json")
    spatial_geom = evaluate_geometric_upper_bound()
    write_json(SYNTHESIS_DIR / "spatial_geometry_bounds.json", spatial_geom)

    prompt_ens = analyze_saved_probing_ensembles(
        output_path=SYNTHESIS_DIR / "prompt_sensitivity_and_ensembles.json"
    )
    bpe_diag = analyze_bpe_tokenization(output_path=SYNTHESIS_DIR / "vietnamese_bpe_diagnostics.json")

    md = build_synthesis_markdown(blinded, spatial_psr, spatial_geom, prompt_ens, bpe_diag)
    (SYNTHESIS_DIR / "README.md").write_text(md, encoding="utf-8")
    return {
        "synthesis_dir": SYNTHESIS_DIR.relative_to(ROOT).as_posix(),
        "files_written": [
            "blinded_review_manifest.json",
            "spatial_mechanism_psr.json",
            "spatial_geometry_bounds.json",
            "prompt_sensitivity_and_ensembles.json",
            "vietnamese_bpe_diagnostics.json",
            "README.md",
        ],
    }


if __name__ == "__main__":
    print(run_all_synthesis(), flush=True)


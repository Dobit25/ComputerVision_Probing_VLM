"""Audit saved results without importing ML libraries or running inference."""

import argparse
import csv
import json
import math
from collections import Counter
from pathlib import Path

from .evaluate import inside_repo, sha256


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify(directory):
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    require(manifest["status"] == "completed", "Run did not complete.")
    expected_files = {"config.json", "environment.json", "classes.json", "predictions.csv",
                      "metrics.json", "per_class.csv", "confusion_matrix.csv"}
    require(set(manifest["artifact_sha256"]) == expected_files, "Missing or unexpected artifact hashes.")
    for name, expected in manifest["artifact_sha256"].items():
        require(sha256(directory / name) == expected, f"Artifact changed: {name}")
    config = json.loads((directory / "config.json").read_text(encoding="utf-8"))
    classes = json.loads((directory / "classes.json").read_text(encoding="utf-8"))
    metrics = json.loads((directory / "metrics.json").read_text(encoding="utf-8"))
    require(len(classes) == 100, "Expected 100 fine classes.")
    for i, item in enumerate(classes):
        require(item["class_id"] == i, "Class mapping is out of order.")
        prompt_name = item["dataset_name"].replace("_", " ")
        require(item["prompt_name"] == prompt_name, "Incorrect prompt class name.")
        require(item["prompt"] == config["prompt_template"].format(**{"class": prompt_name}), "Incorrect prompt.")
    with (directory / "predictions.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    count = config["limit"] if config["limit"] is not None else 10000
    require(len(rows) == count == metrics["num_samples"], "Prediction count mismatch.")
    require(manifest["dataset"]["evaluated_samples"] == count, "Manifest count mismatch.")
    require(manifest["mode"] == ("full_test" if count == 10000 else "smoke_test"), "Incorrect run scope.")
    require(metrics["num_classes"] == 100, "Incorrect metric class count.")
    support, correct_by_class = Counter(), Counter()
    confusion = [[0] * 100 for _ in range(100)]
    for index, row in enumerate(rows):
        require(int(row["test_index"]) == index, "Test indices missing, duplicated or out of order.")
        require(row["sample_id"] == f"cifar100/test/{index:05d}", "Sample ID mismatch.")
        true_id, pred_id = int(row["target_id"]), int(row["prediction_id"])
        require(0 <= true_id < 100 and 0 <= pred_id < 100, "Class ID out of bounds.")
        require(row["target_name"] == classes[true_id]["dataset_name"], "Target name mismatch.")
        require(row["prediction_name"] == classes[pred_id]["dataset_name"], "Prediction name mismatch.")
        correct = int(true_id == pred_id)
        require(int(row["correct"]) == correct, "Incorrect correct/incorrect flag.")
        best, true = float(row["predicted_cosine"]), float(row["target_cosine"])
        margin = float(row["top1_top2_margin"])
        require(all(math.isfinite(x) for x in [best, true, margin]), "Non-finite scores.")
        require(-1.00001 <= true <= best + 1e-6 and -1.00001 <= best <= 1.00001, "Invalid cosine scores.")
        require(0 <= margin <= 2.00001, "Invalid cosine margin.")
        if correct:
            require(math.isclose(best, true, abs_tol=1e-6), "Correct prediction has inconsistent scores.")
        support[true_id] += 1
        correct_by_class[true_id] += correct
        confusion[true_id][pred_id] += 1
    correct = sum(correct_by_class.values())
    require(correct == metrics["correct"], "Correct count differs from predictions.")
    require(math.isclose(correct / count, metrics["top1_accuracy"], abs_tol=1e-12), "Accuracy mismatch.")
    require(math.isclose(100 * correct / count, metrics["top1_accuracy_percent"], abs_tol=1e-10), "Percent mismatch.")
    with (directory / "per_class.csv").open(encoding="utf-8", newline="") as handle:
        per_class = list(csv.DictReader(handle))
    require(len(per_class) == 100, "Per-class table is incomplete.")
    for i, row in enumerate(per_class):
        require(int(row["class_id"]) == i and row["class_name"] == classes[i]["dataset_name"], "Per-class mapping mismatch.")
        require(int(row["support"]) == support[i] and int(row["correct"]) == correct_by_class[i], "Per-class counts mismatch.")
        if support[i]:
            require(math.isclose(float(row["accuracy"]), correct_by_class[i] / support[i], abs_tol=1e-12), "Per-class accuracy mismatch.")
        else:
            require(row["accuracy"] == "", "Absent classes must have undefined accuracy.")
    with (directory / "confusion_matrix.csv").open(encoding="utf-8", newline="") as handle:
        matrix_rows = list(csv.reader(handle))
    require(matrix_rows[0] == ["true_class_id", "true_class_name", *map(str, range(100))], "Confusion columns mismatch.")
    require(len(matrix_rows) == 101, "Confusion rows mismatch.")
    for i, row in enumerate(matrix_rows[1:]):
        require(row[:2] == [str(i), classes[i]["dataset_name"]], "Confusion row label mismatch.")
        require(list(map(int, row[2:])) == confusion[i], "Confusion counts mismatch.")
    if count == 10000:
        require(all(support[i] == 100 for i in range(100)), "Full test must contain 100 images per class.")
    return {"verified": True, "mode": manifest["mode"], "num_samples": count,
            "correct": correct, "top1_accuracy_percent": 100 * correct / count}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_directory")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    print(json.dumps(verify(inside_repo(root, args.run_directory)), indent=2))


if __name__ == "__main__":
    main()

"""Fixed baseline protocol; no training, prompt search, or test-time augmentation."""

import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import random
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from .metrics import classification_metrics


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, payload):
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def inside_repo(root, value):
    path = (root / value).resolve()
    if not path.is_relative_to(root) or path == root:
        raise ValueError(f"Path must be inside the project folder: {value}")
    return path


def command_output(command, root):
    try:
        result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=15, check=True)
        return result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None


def configure_paths(root):
    cache = root / ".cache"
    for variable, subdir in {
        "HF_HOME": "huggingface", "TORCH_HOME": "torch", "XDG_CACHE_HOME": "xdg",
        "MPLCONFIGDIR": "matplotlib", "TEMP": "tmp", "TMP": "tmp", "TMPDIR": "tmp",
    }.items():
        path = cache / subdir
        path.mkdir(parents=True, exist_ok=True)
        os.environ[variable] = str(path)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"


def read_config(root, args):
    config = json.loads(inside_repo(root, args.config).read_text(encoding="utf-8"))
    required = {
        "protocol_version", "model", "pretrained", "checkpoint_url", "checkpoint_sha256",
        "dataset", "dataset_download_url", "split", "prompt_template", "class_name_policy", "precision", "device",
        "batch_size", "num_workers", "seed", "cpu_threads", "data_dir", "model_dir", "results_dir",
    }
    if set(config) != required:
        raise ValueError(f"Config keys differ from schema: {set(config) ^ required}")
    fixed = {
        "protocol_version": 1, "model": "ViT-B-32", "pretrained": "openai",
        "dataset": "CIFAR100", "split": "test", "prompt_template": "a photo of a {class}.",
        "class_name_policy": "replace_underscores_with_spaces", "precision": "fp32",
        "num_workers": 0,
        "checkpoint_url": "https://openaipublic.azureedge.net/clip/models/40d365715913c9da98579312b702a82c18be219cc2a73407c4526f58eba950af/ViT-B-32.pt",
        "checkpoint_sha256": "40d365715913c9da98579312b702a82c18be219cc2a73407c4526f58eba950af",
    }
    for key, expected in fixed.items():
        if config[key] != expected:
            raise ValueError(f"Protocol v1 fixes {key}={expected!r}; use a new protocol for other experiments.")
    for key in ("batch_size", "device"):
        override = getattr(args, key)
        if override is not None:
            config[key] = override
    for key in ("batch_size", "cpu_threads"):
        if type(config[key]) is not int or config[key] <= 0:
            raise ValueError(f"{key} must be a positive integer.")
    if type(config["seed"]) is not int or not 0 <= config["seed"] < 2**32:
        raise ValueError("seed must be an integer in [0, 2**32).")
    if config["device"] not in ("cpu", "cuda"):
        raise ValueError("device must be cpu or cuda.")
    if config["dataset_download_url"] not in (
        "https://dataset.bj.bcebos.com/cifar/cifar-100-python.tar.gz",
        "https://www.cs.toronto.edu/~kriz/cifar-100-python.tar.gz",
    ):
        raise ValueError("Use the documented CIFAR-100 origin or mirror URL.")
    if args.limit is not None and not 1 <= args.limit <= 10000:
        raise ValueError("--limit must be between 1 and 10000.")
    config["limit"] = args.limit
    config["selection"] = "all_test_indices" if args.limit is None else "first_n_test_indices"
    for key in ("data_dir", "model_dir", "results_dir"):
        inside_repo(root, config[key])
    return config


def run(root, args):
    config = read_config(root, args)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    run_name = args.run_name or f"{'smoke' if args.limit is not None else 'full'}_{stamp}"
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,100}", run_name):
        raise ValueError("Run name must be a short directory name using letters, digits, _, - or .")
    output = inside_repo(root, config["results_dir"]) / run_name
    if output.exists():
        raise FileExistsError(f"Run already exists: {output}. Choose a new --run-name.")
    output.mkdir(parents=True)
    configure_paths(root)
    manifest = {
        "status": "running", "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "command_argv": sys.argv, "run_name": run_name,
        "git_head": command_output(["git", "rev-parse", "HEAD"], root),
        "git_status": command_output(["git", "status", "--short", "--untracked-files=normal"], root),
        "source_sha256": {
            str(p.relative_to(root)).replace("\\", "/"): sha256(p)
            for p in sorted([*root.glob("vlm_probe/*.py"), root / "requirements.txt",
                             inside_repo(root, args.config)])
        },
    }
    write_json(output / "config.json", config)
    write_json(output / "manifest.json", manifest)
    started = time.perf_counter()
    try:
        evaluate(root, output, config, manifest)
        manifest["status"] = "completed"
    except BaseException as error:
        manifest["status"] = "failed"
        manifest["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        manifest["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        manifest["wall_seconds"] = time.perf_counter() - started
        write_json(output / "manifest.json", manifest)


def evaluate(root, output, config, manifest):
    print(f"Run directory: {output}\nLoading libraries...", flush=True)
    import numpy as np
    import open_clip
    import torch
    from torch.utils.data import DataLoader, Subset
    from torchvision.datasets import CIFAR100

    device = torch.device(config["device"])
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; fix the environment or explicitly use --device cpu.")
    random.seed(config["seed"])
    np.random.seed(config["seed"])
    torch.manual_seed(config["seed"])
    torch.set_num_threads(config["cpu_threads"])
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.set_float32_matmul_precision("highest")
    packages = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions() if d.metadata["Name"]}
    write_json(output / "environment.json", {
        "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
        "packages": dict(sorted(packages.items(), key=lambda pair: pair[0].lower())),
        "torch_cuda_build": torch.version.cuda, "cudnn_version": torch.backends.cudnn.version(),
        "device": str(device), "gpu": torch.cuda.get_device_name(0) if device.type == "cuda" else None,
        "gpu_driver": command_output(["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"], root),
        "deterministic_algorithms": True, "cublas_workspace_config": os.environ["CUBLAS_WORKSPACE_CONFIG"],
        "tf32": False, "cpu_threads": torch.get_num_threads(),
    })

    checkpoint = inside_repo(root, config["model_dir"]) / "ViT-B-32.pt"
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    if not checkpoint.exists():
        print("Downloading official pretrained checkpoint...", flush=True)
        torch.hub.download_url_to_file(config["checkpoint_url"], str(checkpoint),
                                       hash_prefix=config["checkpoint_sha256"], progress=True)
    actual_hash = sha256(checkpoint)
    if actual_hash != config["checkpoint_sha256"]:
        raise RuntimeError(f"Checkpoint SHA256 mismatch: {checkpoint}. Remove or replace the corrupt file.")
    pretrained_cfg = open_clip.get_pretrained_cfg(config["model"], config["pretrained"])
    print("Checkpoint verified. Loading pretrained CLIP with QuickGELU...", flush=True)
    model, _, preprocess = open_clip.create_model_and_transforms(
        config["model"], pretrained=str(checkpoint), device=device, precision="fp32",
        force_quick_gelu=True, image_mean=pretrained_cfg["mean"], image_std=pretrained_cfg["std"],
        image_interpolation=pretrained_cfg["interpolation"], image_resize_mode=pretrained_cfg["resize_mode"],
        # The SHA256-verified official checkpoint is a TorchScript archive.
        weights_only=False, cache_dir=str(inside_repo(root, config["model_dir"])),
    )
    model.eval()
    model.requires_grad_(False)
    tokenizer = open_clip.get_tokenizer(config["model"])
    print("Preparing CIFAR-100 official test split (checksum-verified archive)...", flush=True)
    class DownloadableCIFAR100(CIFAR100):
        # The mirror carries the same archive; torchvision still enforces the original MD5.
        url = config["dataset_download_url"]

    dataset = DownloadableCIFAR100(root=str(inside_repo(root, config["data_dir"])), train=False,
                                   transform=preprocess, download=True)
    if len(dataset) != 10000 or len(dataset.classes) != 100:
        raise RuntimeError("Unexpected CIFAR-100 test size or number of classes.")
    if dataset.class_to_idx != {name: i for i, name in enumerate(dataset.classes)}:
        raise RuntimeError("Dataset class order does not match target IDs.")
    if sorted(dataset.targets) != [i for i in range(100) for _ in range(100)]:
        raise RuntimeError("Expected exactly 100 test images per fine class.")
    classes = [
        {"class_id": i, "dataset_name": name, "prompt_name": name.replace("_", " "),
         "prompt": config["prompt_template"].format(**{"class": name.replace("_", " ")})}
        for i, name in enumerate(dataset.classes)
    ]
    write_json(output / "classes.json", classes)
    data_root = Path(dataset.root) / dataset.base_folder
    count = config["limit"] if config["limit"] is not None else len(dataset)
    manifest.update({
        "checkpoint": {"url": config["checkpoint_url"], "sha256": actual_hash,
                       "path": checkpoint.relative_to(root).as_posix(), "quick_gelu": True},
        "dataset": {"name": "CIFAR100", "split": "test", "total_test_samples": len(dataset),
                    "evaluated_samples": count, "origin_url": CIFAR100.url,
                    "download_url": dataset.url, "archive_md5": dataset.tgz_md5,
                    "test_sha256": sha256(data_root / "test"), "meta_sha256": sha256(data_root / "meta"),
                    "torchvision_integrity_checked": True},
        "preprocessing": repr(preprocess), "pretrained_config": pretrained_cfg,
        "tokenizer": type(tokenizer).__name__, "context_length": model.context_length,
        "mode": "full_test" if count == len(dataset) else "smoke_test",
    })
    write_json(output / "manifest.json", manifest)
    loader = DataLoader(Subset(dataset, range(count)), batch_size=config["batch_size"],
                        shuffle=False, num_workers=0, pin_memory=device.type == "cuda", drop_last=False)

    def normalize_checked(features):
        if not torch.isfinite(features).all() or (features.norm(dim=-1) <= 0).any():
            raise RuntimeError("Non-finite or zero embedding.")
        normalized = torch.nn.functional.normalize(features.float(), dim=-1)
        if not torch.allclose(normalized.norm(dim=-1), torch.ones(features.shape[0], device=device), atol=1e-5):
            raise RuntimeError("Embedding normalization failed.")
        return normalized

    targets, predictions = [], []
    fields = ["sample_id", "test_index", "target_id", "target_name", "prediction_id", "prediction_name",
              "correct", "predicted_cosine", "target_cosine", "top1_top2_margin"]
    if device.type == "cuda":
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
    evaluation_started = time.perf_counter()
    with torch.inference_mode(), (output / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        tokens = tokenizer([c["prompt"] for c in classes]).to(device)
        text_features = normalize_checked(model.encode_text(tokens))
        if tuple(text_features.shape) != (100, 512):
            raise RuntimeError(f"Unexpected text feature shape: {text_features.shape}")
        print(f"Text embeddings: {tuple(text_features.shape)}; evaluating {count} images...", flush=True)
        for batch_number, (images, labels) in enumerate(loader, start=1):
            start_index = len(targets)
            expected = dataset.targets[start_index:start_index + len(labels)]
            if labels.tolist() != expected:
                raise RuntimeError("DataLoader targets differ from official test index order.")
            images = images.to(device, non_blocking=device.type == "cuda")
            image_features = normalize_checked(model.encode_image(images))
            if tuple(image_features.shape) != (len(labels), 512):
                raise RuntimeError(f"Unexpected image feature shape: {image_features.shape}")
            scores = image_features @ text_features.T
            if not torch.isfinite(scores).all():
                raise RuntimeError("Non-finite cosine scores.")
            # torch.argmax resolves exact ties to the lowest class index.
            predicted = scores.argmax(dim=1)
            top_two = scores.topk(2, dim=1).values
            batch_predictions = predicted.cpu().tolist()
            best = scores.gather(1, predicted[:, None]).squeeze(1).cpu().tolist()
            true_scores = scores.gather(1, labels.to(device)[:, None]).squeeze(1).cpu().tolist()
            margins = (top_two[:, 0] - top_two[:, 1]).cpu().tolist()
            for offset, (target, prediction) in enumerate(zip(expected, batch_predictions)):
                index = start_index + offset
                writer.writerow({
                    "sample_id": f"cifar100/test/{index:05d}", "test_index": index,
                    "target_id": target, "target_name": dataset.classes[target],
                    "prediction_id": prediction, "prediction_name": dataset.classes[prediction],
                    "correct": int(target == prediction), "predicted_cosine": best[offset],
                    "target_cosine": true_scores[offset], "top1_top2_margin": margins[offset],
                })
            targets.extend(expected)
            predictions.extend(batch_predictions)
            handle.flush()
            if batch_number == 1 or batch_number % 10 == 0 or len(targets) == count:
                print(f"Evaluated {len(targets)}/{count} images", flush=True)
    if device.type == "cuda":
        torch.cuda.synchronize()
    metrics, per_class, confusion = classification_metrics(targets, predictions, dataset.classes)
    metrics["evaluation_seconds"] = time.perf_counter() - evaluation_started
    metrics["images_per_second"] = count / metrics["evaluation_seconds"]
    metrics["peak_cuda_memory_allocated_bytes"] = torch.cuda.max_memory_allocated() if device.type == "cuda" else None
    write_json(output / "metrics.json", metrics)
    with (output / "per_class.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(per_class[0]))
        writer.writeheader()
        writer.writerows(per_class)
    with (output / "confusion_matrix.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["true_class_id", "true_class_name", *range(100)])
        for i, row in enumerate(confusion):
            writer.writerow([i, dataset.classes[i], *row])
    manifest["embedding_dimensions"] = {"image": 512, "text": 512, "text_classes": 100}
    manifest["artifact_sha256"] = {p.name: sha256(p) for p in sorted(output.iterdir()) if p.name != "manifest.json"}
    print(f"Top-1: {metrics['correct']}/{count} = {metrics['top1_accuracy_percent']:.4f}%", flush=True)
    print(f"Artifacts saved to: {output}", flush=True)

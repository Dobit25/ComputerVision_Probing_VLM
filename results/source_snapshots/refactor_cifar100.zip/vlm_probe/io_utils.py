"""Filesystem and provenance utilities shared by runners and audits."""

import hashlib
import json
import os
import subprocess
from pathlib import Path


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, payload):
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def inside_repo(root, value):
    path = (root / value).resolve()
    if not path.is_relative_to(root) or path == root:
        raise ValueError(f"Path must be inside the project folder: {value}")
    return path


def command_output(command, root):
    try:
        result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=15, check=True)
        return result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None


def configure_paths(root):
    cache = root / ".cache"
    for variable, subdir in {
        "HF_HOME": "huggingface", "TORCH_HOME": "torch", "XDG_CACHE_HOME": "xdg",
        "MPLCONFIGDIR": "matplotlib", "TEMP": "tmp", "TMP": "tmp", "TMPDIR": "tmp",
    }.items():
        path = cache / subdir
        path.mkdir(parents=True, exist_ok=True)
        os.environ[variable] = str(path)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"


